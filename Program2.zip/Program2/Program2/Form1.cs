﻿//K4312
//Program 2
//Due October 16, 2019
//Takes user input of Last name and Earned credit hours, and displays when they can register for classes for the Spring 2020 semester.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            classLbl.Text = "";     //Sets the output label to blank. Looks cleaner
            dateLbl.Text = "";      //Sets the output label to blank. Looks cleaner     
            timeLbl.Text = "";      //Sets the output label to blank. Looks cleaner
        }

        private void Button1_Click(object sender, EventArgs e)
        {

            const string TIMEONE = "8:30 AM",               //Constant. Earliest Time slot.
                TIMETWO = "10:00 AM",                       //Constant. Second Time slot of the day.
                TIMETHREE = "11:30 AM",                     //Constant. Third Time slot of the day.
                TIMEFOUR = "2:00 PM",                       //Constant. Fourth time slot of the day.
                TIMEFIVE = "4:00 PM";                       //Constant. Last time slot of the day.
            const string DATEONE = "Monday, November 4",    //Constant. First day to register.
                DATETWO = "Tuesday, November 5",            //Constant. Second day to register.
                DATETHREE = "Wednesday, November 6",        //Constant. Third day to register.
                DATEFOUR = "Thursday, November 7",          //Constant. Fourth day to register.  
                DATEFIVE = "Friday, November 8",            //Constant. Fifth day to register.
                DATESIX = "Monday, November 11";            //Constant. Sixth day to register.
            const double SENIOR = 90,                       //Constant. Minimum credits to be a senior.
                JUNIOR = 60,                                //Constant. Mimumum credits to be a junior.
                SOPHOMORE = 30;                             //Constant. Mimumum credits to be a sophomore.

            double credits;                         //Will hold user input of credits.
            char lastName;                          //Will hold first letter of user input last name.
            lastNameTxt.Text.ToLower();             //Converts last name to lower case.

            if (lastNameTxt.Text != "")             //Tests to see if user left the box blank
            {
                lastName = lastNameTxt.Text[0];     //Assigns first letter for user input of last name to lastName variable.
                if (char.IsLetter(lastName))        //Tests to see if the character is a letter. (cannot be number)
                {
                    if (double.TryParse(creditsTxt.Text, out credits) && credits >= 0)      //Tests to see if credits is a positive number.
                    {
                        if (credits >= SENIOR)                          //Tests if credits are high enough to be considered a senior.
                        {
                            classLbl.Text = "You are a Senior";         //Assigns class label to Senior.
                            dateLbl.Text = DATEONE;                     //Assigns date label to date one
                            if (lastName <= 'd')                        //Tests if last name letter is A-D
                                timeLbl.Text = TIMETHREE;               //Assigns time to time three.
                            else if (lastName <= 'i')                   //Tests E-I
                                timeLbl.Text = TIMEFOUR;                //Assigns time four
                            else if (lastName <= 'o')                   //Tests J-O
                                timeLbl.Text = TIMEFIVE;                //Assigns time five
                            else if (lastName <= 's')                   //Tests P-S
                                timeLbl.Text = TIMEONE;                 //Assigns time one
                            else
                                timeLbl.Text = TIMETWO;                 //Assigns T-Z to time two.
                        }
                        else if (credits >= JUNIOR)                     //Tests if credits are high enough to be a junior.
                        {
                            classLbl.Text = "You are a Junior";         //Assigns class label to junior
                            dateLbl.Text = DATETWO;                     //Assigns date label to date two
                            if (lastName <= 'd')                        //Tests A-D
                                timeLbl.Text = TIMETHREE;               //Assigns time to time three.
                            else if (lastName <= 'i')                   //Tests E-I
                                timeLbl.Text = TIMEFOUR;                //Assigns time four
                            else if (lastName <= 'o')                   //Tests J-O
                                timeLbl.Text = TIMEFIVE;                //Assigns time five
                            else if (lastName <= 's')                   //Tests P-S
                                timeLbl.Text = TIMEONE;                 //Assigns time one
                            else
                                timeLbl.Text = TIMETWO;                 //Assigns time two
                        }
                        else if (credits >= SOPHOMORE)                  //Tests if sophomore
                        {
                            classLbl.Text = "You are a Sophomore";      //Assigns class label to sophomore
                            if (lastName <= 'b')                        //Tests A-B
                            {
                                dateLbl.Text = DATETHREE;               //Assigns date three
                                timeLbl.Text = TIMEFIVE;                //Assigns time five
                            }
                            else if (lastName <= 'd')                   //Tests C-D
                            {
                                dateLbl.Text = DATEFOUR;
                                timeLbl.Text = TIMEONE;
                            }
                            else if (lastName <= 'f')                   //Tests E-F
                            {
                                dateLbl.Text = DATEFOUR;
                                timeLbl.Text = TIMETWO;
                            }
                            else if (lastName <= 'i')                   //Tests G-I
                            {
                                dateLbl.Text = DATEFOUR;
                                timeLbl.Text = TIMETHREE;
                            }
                            else if (lastName <= 'l')                   //Tests J-L
                            {
                                dateLbl.Text = DATEFOUR;
                                timeLbl.Text = TIMEFOUR;
                            }
                            else if (lastName <= 'o')                   //Tests M-O
                            {
                                dateLbl.Text = DATEFOUR;
                                timeLbl.Text = TIMEFIVE;
                            }
                            else if (lastName <= 'q')                   //Tests P-Q
                            {
                                dateLbl.Text = DATETHREE;
                                timeLbl.Text = TIMEONE;
                            }
                            else if (lastName <= 's')                   //Tests R-S
                            {
                                dateLbl.Text = DATETHREE;
                                timeLbl.Text = TIMETWO;
                            }
                            else if (lastName <= 'v')                   //Tests T-V
                            {
                                dateLbl.Text = DATETHREE;
                                timeLbl.Text = TIMETHREE;
                            }
                            else                                        //Assigns W-Z
                            {
                                dateLbl.Text = DATETHREE;
                                timeLbl.Text = TIMEFOUR;
                            }

                        }
                        else
                        {
                            classLbl.Text = "You are a Freshman";       //Assigns Freshman to class
                            if (lastName <= 'b')                        //Tests A-B
                            {
                                dateLbl.Text = DATEFIVE;
                                timeLbl.Text = TIMEFIVE;
                            }
                            else if (lastName <= 'd')                   //Tests C-D
                            {
                                dateLbl.Text = DATESIX;
                                timeLbl.Text = TIMEONE;
                            }
                            else if (lastName <= 'f')                   //Tests E-F
                            {
                                dateLbl.Text = DATESIX;
                                timeLbl.Text = TIMETWO;
                            }
                            else if (lastName <= 'i')                   //Tests G-I
                            {
                                dateLbl.Text = DATESIX;
                                timeLbl.Text = TIMETHREE;
                            }
                            else if (lastName <= 'l')                   //Tests J-L
                            {
                                dateLbl.Text = DATESIX;
                                timeLbl.Text = TIMEFOUR;
                            }
                            else if (lastName <= 'o')                   //Tests M-O
                            {
                                dateLbl.Text = DATESIX;
                                timeLbl.Text = TIMEFIVE;
                            }
                            else if (lastName <= 'q')                   //Tests P-Q
                            {
                                dateLbl.Text = DATEFIVE;
                                timeLbl.Text = TIMEONE;
                            }
                            else if (lastName <= 's')                   //Tests R-S
                            {
                                dateLbl.Text = DATEFIVE;
                                timeLbl.Text = TIMETWO;
                            }
                            else if (lastName <= 'v')                   //Tests T-V
                            {
                                dateLbl.Text = DATEFIVE;
                                timeLbl.Text = TIMETHREE;
                            }
                            else                                        //Assigns W-Z to date five, time four
                            {
                                dateLbl.Text = DATEFIVE;
                                timeLbl.Text = TIMEFOUR;
                            }
                        }    
                    }
                    else
                        MessageBox.Show("Invalid Input for Credits Earned. This should be a positive number.");     //If credits is negative or blank, you get this message.
                }
                else
                    MessageBox.Show("Invalid Input for Last Name. Last Name should only contain letters.");         //If Last name, first letter is NOT a letter, you get this message.
            }
            else
                MessageBox.Show("Invalid Input for Last Name. Please enter a last name.");                          //If Last name is left blank, you get this message.
        }
    }
}