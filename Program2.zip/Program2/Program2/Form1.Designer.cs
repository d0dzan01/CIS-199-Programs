﻿namespace Program2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lastNameTxt = new System.Windows.Forms.TextBox();
            this.lastNameLbl = new System.Windows.Forms.Label();
            this.creditsLbl = new System.Windows.Forms.Label();
            this.creditsTxt = new System.Windows.Forms.TextBox();
            this.scheduleBtn = new System.Windows.Forms.Button();
            this.classLbl = new System.Windows.Forms.Label();
            this.dateLbl = new System.Windows.Forms.Label();
            this.timeLbl = new System.Windows.Forms.Label();
            this.yearLbl = new System.Windows.Forms.Label();
            this.regDateLbl = new System.Windows.Forms.Label();
            this.regTimeLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lastNameTxt
            // 
            this.lastNameTxt.Location = new System.Drawing.Point(161, 9);
            this.lastNameTxt.Name = "lastNameTxt";
            this.lastNameTxt.Size = new System.Drawing.Size(100, 20);
            this.lastNameTxt.TabIndex = 3;
            // 
            // lastNameLbl
            // 
            this.lastNameLbl.AutoSize = true;
            this.lastNameLbl.Location = new System.Drawing.Point(85, 12);
            this.lastNameLbl.Name = "lastNameLbl";
            this.lastNameLbl.Size = new System.Drawing.Size(61, 13);
            this.lastNameLbl.TabIndex = 2;
            this.lastNameLbl.Text = "Last Name:";
            // 
            // creditsLbl
            // 
            this.creditsLbl.AutoSize = true;
            this.creditsLbl.Location = new System.Drawing.Point(15, 46);
            this.creditsLbl.Name = "creditsLbl";
            this.creditsLbl.Size = new System.Drawing.Size(131, 13);
            this.creditsLbl.TabIndex = 4;
            this.creditsLbl.Text = "Number of Credits Earned:";
            // 
            // creditsTxt
            // 
            this.creditsTxt.Location = new System.Drawing.Point(161, 43);
            this.creditsTxt.Name = "creditsTxt";
            this.creditsTxt.Size = new System.Drawing.Size(100, 20);
            this.creditsTxt.TabIndex = 5;
            // 
            // scheduleBtn
            // 
            this.scheduleBtn.Location = new System.Drawing.Point(65, 84);
            this.scheduleBtn.Name = "scheduleBtn";
            this.scheduleBtn.Size = new System.Drawing.Size(162, 23);
            this.scheduleBtn.TabIndex = 6;
            this.scheduleBtn.Text = "When do I Schedule Classes?";
            this.scheduleBtn.UseVisualStyleBackColor = true;
            this.scheduleBtn.Click += new System.EventHandler(this.Button1_Click);
            // 
            // classLbl
            // 
            this.classLbl.AutoSize = true;
            this.classLbl.Location = new System.Drawing.Point(131, 149);
            this.classLbl.Name = "classLbl";
            this.classLbl.Size = new System.Drawing.Size(28, 13);
            this.classLbl.TabIndex = 7;
            this.classLbl.Text = "XXX";
            // 
            // dateLbl
            // 
            this.dateLbl.AutoSize = true;
            this.dateLbl.Location = new System.Drawing.Point(131, 177);
            this.dateLbl.Name = "dateLbl";
            this.dateLbl.Size = new System.Drawing.Size(28, 13);
            this.dateLbl.TabIndex = 8;
            this.dateLbl.Text = "YYY";
            // 
            // timeLbl
            // 
            this.timeLbl.AutoSize = true;
            this.timeLbl.Location = new System.Drawing.Point(131, 205);
            this.timeLbl.Name = "timeLbl";
            this.timeLbl.Size = new System.Drawing.Size(28, 13);
            this.timeLbl.TabIndex = 9;
            this.timeLbl.Text = "ZZZ";
            // 
            // yearLbl
            // 
            this.yearLbl.AutoSize = true;
            this.yearLbl.Location = new System.Drawing.Point(85, 149);
            this.yearLbl.Name = "yearLbl";
            this.yearLbl.Size = new System.Drawing.Size(38, 13);
            this.yearLbl.TabIndex = 10;
            this.yearLbl.Text = "Class: ";
            // 
            // regDateLbl
            // 
            this.regDateLbl.AutoSize = true;
            this.regDateLbl.Location = new System.Drawing.Point(31, 177);
            this.regDateLbl.Name = "regDateLbl";
            this.regDateLbl.Size = new System.Drawing.Size(92, 13);
            this.regDateLbl.TabIndex = 11;
            this.regDateLbl.Text = "Registration Date:";
            // 
            // regTimeLbl
            // 
            this.regTimeLbl.AutoSize = true;
            this.regTimeLbl.Location = new System.Drawing.Point(31, 205);
            this.regTimeLbl.Name = "regTimeLbl";
            this.regTimeLbl.Size = new System.Drawing.Size(92, 13);
            this.regTimeLbl.TabIndex = 12;
            this.regTimeLbl.Text = "Registration Time:";
            // 
            // Form1
            // 
            this.AcceptButton = this.scheduleBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(294, 256);
            this.Controls.Add(this.regTimeLbl);
            this.Controls.Add(this.regDateLbl);
            this.Controls.Add(this.yearLbl);
            this.Controls.Add(this.timeLbl);
            this.Controls.Add(this.dateLbl);
            this.Controls.Add(this.classLbl);
            this.Controls.Add(this.scheduleBtn);
            this.Controls.Add(this.creditsTxt);
            this.Controls.Add(this.creditsLbl);
            this.Controls.Add(this.lastNameTxt);
            this.Controls.Add(this.lastNameLbl);
            this.Name = "Form1";
            this.Text = "Program 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox lastNameTxt;
        private System.Windows.Forms.Label lastNameLbl;
        private System.Windows.Forms.Label creditsLbl;
        private System.Windows.Forms.TextBox creditsTxt;
        private System.Windows.Forms.Button scheduleBtn;
        private System.Windows.Forms.Label classLbl;
        private System.Windows.Forms.Label dateLbl;
        private System.Windows.Forms.Label timeLbl;
        private System.Windows.Forms.Label yearLbl;
        private System.Windows.Forms.Label regDateLbl;
        private System.Windows.Forms.Label regTimeLbl;
    }
}

