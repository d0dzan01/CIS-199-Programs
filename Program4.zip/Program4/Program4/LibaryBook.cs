﻿//K4312
//Program 4
//Due December 3, 2019
//Section 02
//This program lists a series of libary books and tells whether or not the book is checked out.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class LibraryBook
{
    private string _title;          //backing field for title
    private string _author;         //backing field for author
    private string _publisher;      //backing field for publisher
    private int _copyrightYear;     //backing field for copyright year
    private string _callNumber;     //backing field for call number


    public string Title
    {
        //Precondition: None
        //Postcondition: the title is returned
        get { return _title; }

        //Precondition: None
        //Postcondition: the title is set to the specified value
        set { _title = value; }
    }

    public string Author
    {
        //Precondition: None
        //Postcondition: the author is returned
        get { return _author; }

        //Precondition: None
        //Postcondition: the author is set to the specified value
        set { _author = value; }
    }

    public string Publisher
    {
        //Precondition: None
        //Postcondition: the publisher is returned
        get { return _publisher; }

        //Precondition: None
        //Postcondition: the publisher is set to the specified value
        set { _publisher = value; }
    }

    public int CopyrightYear
    {
        //Precondition: None
        //Postcondition: the copyright year is returned
        get { return _copyrightYear; }

        //Precondition: the value must be positive, else, 2019 is returned.
        //Postcondition: the copyright year is set to the specified value
        set
        {
            if (value >= 0)
                _copyrightYear = value;
            else
                _copyrightYear = 2019;
        }
    }


    public string CallNumber
    {
        //Precondition: None
        //Postcondition: the call number is returned
        get { return _callNumber; }

        //Precondition: None
        //Postcondition: the call number is set to the specified value
        set { _callNumber = value; }
    }


    //Precondition: None
    //Postcondition: a book is constructed with the title, author, publisher, year, and call number
    public LibraryBook(string title, string author, string pub, int year, string num)
    {
        Title = title;
        Author = author;
        Publisher = pub;
        CopyrightYear = year;
        CallNumber = num;
    }
    bool checkedOut = false; // default checked out value is false

    //Precondition: None
    //Postcondition: the book is now checked out
    public void Checkout()
    {
        bool checkedOut = true;
    }

    //Precondition: None
    //Postcondition: the book is not checked out anymore, and is returned to shelf
    public void ReturnToShelf()
    {
        bool checkedOut = false;
    }

    //Precondition: None
    //Postcondition: returns if the book is checked out or not
    public bool IsCheckedOut()
    {
        if (checkedOut)
            return true;
        else
            return false;
    }

    //Precondition: None
    //Postcondition: returns the values for all labels.
    public override string ToString()
    {
        return $"Title: {base.ToString()}{Environment.NewLine}" +
            $"Author: {Author}{Environment.NewLine}" +
            $"Publisher: {Publisher}{Environment.NewLine}" +
            $"Copyright Year: {CopyrightYear}{Environment.NewLine}" +
            $"Call Number: {CallNumber}{Environment.NewLine}" +
            $"Is it checked out? {IsCheckedOut()}";
    }
}
