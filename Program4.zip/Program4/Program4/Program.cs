﻿//K4312
//Program 4
//Due December 3, 2019
//Section 02
//This program lists a series of libary books and tells whether or not the book is checked out.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Program4
{
    class Program
    {
        static void Main(string[] args)
        {
            LibraryBook[] books = new LibraryBook[5];
            books[0] = new LibraryBook("Book1", "Bob", "Pub", 2018, "31");
            books[1] = new LibraryBook("Book2", "Bob", "Pub", 2017, "32");
            books[2] = new LibraryBook("Book3", "Bob", "Pub", 2016, "33");
            books[3] = new LibraryBook("Book4", "Bob", "Pub", 2015, "34");
            books[4] = new LibraryBook("Book5", "Bob", "Pub", 2014, "35");
        }
        static void LibBooks(LibraryBook[] books)
        {
            foreach (LibraryBook book in books)
            {
                WriteLine($"{book}");
                WriteLine($"{book.IsCheckedOut()}");
            }
        }
    }
}
