﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

public class LibraryBook
{
    private string _title;
    private string _author;
    private string _publisher;
    private int _copyrightYear;
    private string _callNumber;

	public string Title
    { 
        get { return _title; }
        set { _title = value; }
	}
    public string Author
    {
        get { return _author; }
        set { _author = value; }
    }
    public string Publisher
    {
        get { return _publisher; }
        set { _publisher = value; }
    }
    public int CopyrightYear
    {
        get { return _copyrightYear; }
        set
        {
            if (value >= 0)
                _copyrightYear = value;
            else
                _copyrightYear = 2019;
        }
    }
    public string CallNumber
    {
        get { return _callNumber; }
        set { _callNumber = value; }
    }

    public LibraryBook(string title, string author, string pub, int year, string num)
    {
        Title = title;
        Author = author;
        Publisher = pub;
        CopyrightYear = year;
        CallNumber = num;
    }

    public void Checkout()
    {
        bool checkedOut = true;
    }

    public void ReturnToShelf()
    {
        bool checkedOut = false;
    }

    public bool IsCheckedOut()
    {
        if (checkedOut)
            return true;
        else
            return false;
    }
    public override string ToString()
    {
        return $"Title: {base.ToString()}{Environment.NewLine}" + 
            $"Author: {Author}{Environment.NewLine}" + 
            $"Publisher: {Publisher}{Environment.NewLine}" + 
            $"Copyright Year: {CopyrightYear}{Environment.NewLine}" + 
            $"Call Number: {CallNumber}{Environment.NewLine}" + 
            $"Is it checked out? {IsCheckedOut}";
    }
}
